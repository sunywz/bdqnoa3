$().ready(function(){
	$.fckeditor("description");
});
