var menu = {	
	setting : {
		zTree : '',
		pNode : '',
		isSimpleData : true,
		treeNodeKey : "mid",
		treeNodeParentKey : "pid",
		showLine : true,
		open:true,
		isSimpleData : true, //简单数据
		expandSpeed : "",  
		url1:url,
		root : {
			isRoot : true,
			nodes : []
		},
		/*callback : {
			click : zTreeOnClick
		},
*/
	},

	loadMenuTree : function() {
		/*
		 * 这是登陆成功后的菜单js，它不用传递参数，因为dao直接获取session里面的user，再根据user进行显示
		 */
		$.post("menuitemAction_showMenuitemsByUser.action", null,
				function(data) {
			
				menu.zTree =$("#menuTree").zTree(menu.setting, data.menuitemList);
				
				});
	}
};

function zTreeOnClick(event, treeId, treeNode) {
	menu.pNode = treeNode;
	alert(menu.zTree);
	//alert(menu.pNode.mid);
window.location = 'accessory_findAcfByid.action?parentId='+menu.pNode.mid;
		

};


$().ready(function() {
	menu.loadMenuTree();
	
	menu.zTree.expandAll(true);
	
});
